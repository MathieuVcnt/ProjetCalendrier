package fr.da2i.projetcal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetcalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetcalApplication.class, args);
	}

}
