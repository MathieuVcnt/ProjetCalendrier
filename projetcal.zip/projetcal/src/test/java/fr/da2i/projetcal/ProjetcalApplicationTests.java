package fr.da2i.projetcal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetcalApplicationTests {

	@Test
	void contextLoads() {
	}

}
